#!/bin/bash
. /etc/profile
homepath=$(pwd)
LOGTIME=$(date "+%Y-%m-%d %H:%M:%S")
# 本机 Nginx 版本
NGINX_VERSION_OLD=$(cat $homepath/nginx-ver)
NGINX_VERSION=$(wget -qO- --no-check-certificate https://nginx-build.lm317379829.repl.co/nginx/nginx-ver)
# 检查更新
if [ "$NGINX_VERSION_OLD" == "$NGINX_VERSION" ]; then
  echo "[$LOGTIME] 当前Nginx为最新版$NGINX_VERSION" 
  exit
fi

# 更新 Nginx
rm $homepath/nginx
wget -qO- --no-check-certificate https://nginx-build.lm317379829.repl.co/nginx/nginx -O $homepath/nginx
chmod +x $homepath/nginx
echo -n $NGINX_VERSION > $homepath/nginx-ver
bash $homepath/dog.sh reload_nginx