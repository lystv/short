#!/bin/bash
. /etc/profile
LOGTIME=$(date "+%Y-%m-%d %H:%M:%S")
CURRENT_DIR=$(cd $(dirname $0); pwd)
for dir in $(ls -l $CURRENT_DIR/html/CJK/repo/ |awk '/^d/ {print $NF}')
do
  RmDir=$(echo $CURRENT_DIR/html/CJK/repo/$dir)
  FileNum=$(ls -Alrt $RmDir|awk '/.zip$/ {print $NF}'|wc -l) 
  while (($FileNum>1))
  do
    OldFile=$(ls -Alrt $RmDir|awk '/.zip$/ {print $NF}'|head -1)
    echo $[LOGTIME] "Delete File:"$RmDir'/'$OldFile
    rm -rf $RmDir'/'$OldFile
    let "FileNum--"
  done
done