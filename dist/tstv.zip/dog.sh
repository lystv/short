#!/bin/bash
. /etc/profile
LOGTIME=$(date "+%Y-%m-%d %H:%M:%S")
CURRENT_DIR=$(cd $(dirname $0); pwd)
nginx_pid=$(ps -ef|grep ./nginx|grep -v grep|awk '{print $2}')
zhibo_pid=$(ps -ef|grep ./zhibo|grep -v grep|awk '{print $2}')

start_nginx()
    {
       ./nginx
}
stop_nginx()      
    {              
       kill $nginx_pid
}
reload_nginx()      
    {              
       ./nginx -s reload
}

start_zhibo()
    {
       ./zhibo /dev/null 2>&1 &
}
stop_zhibo()      
    {              
       kill $zhibo_pid
}



check_nginx()
    { 
           if [ ! -n "$nginx_pid" ]; then
           $CURRENT_DIR/dog.sh start_nginx
           nginx_pid_new=$(ps -ef|grep ./nginx|grep -v grep|awk '{print $2}')
           echo [$LOGTIME] Starting Nginx ...
           echo [$LOGTIME] $nginx_pid_new Nginx
else
        echo [$LOGTIME] $nginx_pid Nginx
fi
}

check_zhibo()
    { 
           if [ ! -n "$zhibo_pid" ]; then
           $CURRENT_DIR/dog.sh start_zhibo
           zhibo_pid_new=$(ps -ef|grep ./zhibo|grep -v grep|awk '{print $2}')
           echo [$LOGTIME] Starting Zhibo ...
           echo [$LOGTIME] $zhibo_pid_new Zhibo
else
        echo [$LOGTIME] $zhibo_pid Zhibo
fi
}

check()
    {
        check_nginx
        check_zhibo
        rm -rf $CURRENT_DIR/easy-cron-log
}

INPUT=$1
if [ -z "$1" ]
then    
check
else     
case "$INPUT" in
start_nginx) start_nginx;;
stop_nginx) stop_nginx;;
reload_nginx) reload_nginx;;
check_nginx) check_nginx;;
start_zhibo) start_zhibo;;
stop_zhibo) stop_zhibo;;
check_zhibo) check_zhibo;;
esac
fi